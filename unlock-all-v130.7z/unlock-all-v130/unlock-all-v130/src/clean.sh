#!/bin/sh
/bin/rm -f Unlocker.Linux32
/bin/rm -f Unlocker.Linux64
/bin/rm -f Unlocker.ESXi

